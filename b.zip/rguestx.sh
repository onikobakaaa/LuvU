#!/bin/bash

RED='\033[0;31m'
GREEN='\033[0;32m'
XYCYAN="\033[36m"
NC='\033[0m'

package_name={com.tencent.ig,com.rekoo.pubgm,com.vng.pubgmobile,com.pubg.krmobile,com.pubg.imobile}
kill $package_name
clear
rm -rf /data/data/$package_name/shared_prefs
mkdir /data/data/$package_name/shared_prefs
chmod 777 /data/data/$package_name/shared_prefs
rm -rf /data/data/$package_name/files
GUEST="/data/data/$package_name/shared_prefs/device_id.xml"
rm -rf $GUEST
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name=\"random\"></string>
    <string name=\"install\"></string>
    <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > $GUEST
rm -rf /data/data/$package_name/databases
rm -rf /data/media/0/Android/data/$package_name/files/login-identifier.txt
rm -rf /data/media/0/Android/data/$package_name/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /data/media/0/Android/data/$package_name/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /data/media/0/Android/data/$package_name/files/TGPA
touch /data/media/0/Android/data/$package_name/files/TGPA
rm -rf /data/media/0/Android/data/$package_name/files/ProgramBinaryCache
touch /data/media/0/Android/data/$package_name/files/ProgramBinaryCache
iptables -I OUTPUT -d cloud.vmp.onezapp.com -j REJECT
iptables -I INPUT -s cloud.vmp.onezapp.com -j REJECT
clear
	echo -e "${GREEN}Reset Guest for $package_name completed.${NC}"
	echo -e "${GREEN}TG: @UwUForHappy${NC}"